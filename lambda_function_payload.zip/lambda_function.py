import json
import boto3
import base64

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # 1. THE HANDSHAKE (CORS)
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }

    # Handle the "Pre-flight" request from the browser
    if event.get('requestContext', {}).get('http', {}).get('method') == 'OPTIONS':
        return {"statusCode": 200, "headers": headers}

    try:
        # 2. THE LOGIC
        body = json.loads(event['body'])
        file_name = body['filename']
        file_data = body['file'].split(",")[-1]
        
        s3.put_object(
            Bucket="ammar-portal-uploads-2026", 
            Key=file_name,
            Body=base64.b64decode(file_data),
            ContentType='image/jpeg'
        )

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({"message": "Successfully uploaded!"})
        }

    except Exception as e:
        print(f"Error: {str(e)}") # This shows up in CloudWatch logs
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)})
        }